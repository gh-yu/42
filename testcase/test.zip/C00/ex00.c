
void ft_putchar(char c);
int main(void)
{
    int i;
    for (i = 0; i < 10; i++)
        ft_putchar('b');
    return 0;
}

