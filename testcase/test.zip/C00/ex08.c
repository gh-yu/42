
void ft_print_combn(int nb);
int main(void)
{
    int i;
    for (i = 1; i <= 9; i++)
    {
        ft_print_combn(i);
    }
    return 0;
}

