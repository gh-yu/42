
void ft_putnbr(int nb);
int main(void)
{
    ft_putnbr(42);
    ft_putnbr(2147483647);
    ft_putnbr(-2147483648);
    ft_putnbr(0);
    ft_putnbr(-42);
    ft_putnbr(1);
    ft_putnbr(-1);
    ft_putnbr(-1010);
    ft_putnbr(1024);
    return 0;
}

