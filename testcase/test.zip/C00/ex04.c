
void ft_is_negative(int n);
int main(void)
{
    int i;
    for (i = -10; i <= 10; i++)
        ft_is_negative(i);
    return 0;
}

