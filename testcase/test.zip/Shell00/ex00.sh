#!/bin/bash
echo Z > z_
cat z_
rm -rf z_
