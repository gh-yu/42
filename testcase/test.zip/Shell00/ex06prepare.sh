printf "ignored1\nignored2\nignored3\nignored4\nignored5" > ../.gitignore
mkdir ignored1
touch ignored1/aaa
touch ignored1/bbb
touch ignored2
touch ignored_NOT
touch ignored3
mkdir ignored4
touch ignored4/ignored
mkdir ignored5
mkdir ignored5/ignored
touch ignored5/ignored/5
touch ign212312312
