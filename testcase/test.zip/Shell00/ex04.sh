#!/bin/bash
ls -Utmp
