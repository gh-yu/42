git rev-list --max-count=5 HEAD
