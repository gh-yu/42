echo Episode V, A NEW H0PE It is a period of civil war$
echo Rebel spaceships, striking from a hidden base, have won their first victory against the evil Galactic Empire. $
echo "During the battle, Rebel spies managed to steal secret plans to the Empire's ultimate weapon, the STAR DEATH, an armored space station with enough power to destroy an entire planet.$"
echo "$"
echo "$"
echo "Pursued by the Empire's sinister agents,$"
echo Princess Mehdi races home aboard her starship, custodian of the stolen plans that can save her people and restore the dictatorship to the galaxie..$
echo $
echo $
echo $
echo $
