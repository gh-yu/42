file -m ft_magic 42 24
