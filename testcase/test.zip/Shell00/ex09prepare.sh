for i in {0..50}
do
	printf "24" >> 42
	printf "42" >> 24
done
