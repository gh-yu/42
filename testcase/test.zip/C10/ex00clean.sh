#!/bin/sh
rm -rf myfile
rm -rf gogogo
