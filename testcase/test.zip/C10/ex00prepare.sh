#!/bin/sh
echo 123456 >> myfile
echo Hello World!! >> myfile
echo GoGoGo >> gogogo
