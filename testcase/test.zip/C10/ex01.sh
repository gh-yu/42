#!/bin/sh
echo "Hello World!! Hello Hello Hello \n World \n WorldWorld \n \?\?"| ./ft_cat | cat -e
./ft_cat gogogo myfile dir dirtest | cat -e
./ft_cat no_way
./ft_cat /exam
