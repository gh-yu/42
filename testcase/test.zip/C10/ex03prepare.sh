#!/bin/sh
echo 123456 >> myfile
echo Hello World!! >> myfile
echo GoGoGo >> gogogo
touch 12345
mkdir dirtest
echo "Hello World!! Hello Hello Hello \n World \n WorldWorld\?\?" > myspeech
