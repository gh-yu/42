#!/bin/sh
rm -rf myfile gogogo 12345 dirtest myspeech
