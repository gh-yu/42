#!/bin/sh
./ft_display_file | cat -e
./ft_display_file 1234 1234 | cat -e
./ft_display_file 1234 | cat -e
./ft_display_file myfile | cat -e
./ft_display_file gogogo | cat -e
