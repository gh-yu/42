
#include <stdio.h>
void ft_ft(int *nbr);
int main(void)
{
    int i;

	i = -1;
	ft_ft(&i);
	printf("%d", i);
    return 0;
}

