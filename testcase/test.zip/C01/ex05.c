
void ft_putstr(char *str);
int main(void)
{
    ft_putstr("Hello 42 SEOUL!!\n");
    ft_putstr("This is a test string\n");
    ft_putstr("Can you display this\?\?!!\?\?!\n");
    return 0;
}

