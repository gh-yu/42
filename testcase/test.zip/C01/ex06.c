
#include <stdio.h>
int ft_strlen(char *str);
int main(void)
{
    printf("%d ", ft_strlen("Hello World!!"));
    printf("%d ", ft_strlen("Can you count this number of characters\?"));
    printf("%d", ft_strlen("THIS IS !!!!!"));
    return 0;
}

