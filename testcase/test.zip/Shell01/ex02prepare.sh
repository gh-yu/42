touch file1.sh
mkdir file2
touch file2/test.sh
touch file2/nonono
touch file3.sh
touch file4
touch file5.sh
touch file6.sh
