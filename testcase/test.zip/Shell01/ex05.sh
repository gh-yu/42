echo '42' | tr -d '\n'
