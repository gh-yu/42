for i in {0..9}
do
    touch 'test_'$i
done
