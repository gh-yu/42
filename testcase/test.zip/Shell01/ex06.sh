#!/bin/bash
ls -l | sed -n 'p;n'
