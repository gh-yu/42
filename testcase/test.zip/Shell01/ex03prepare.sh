for i in {0..74}
do
    touch 'test_'$i
done
