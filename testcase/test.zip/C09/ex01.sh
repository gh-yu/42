#!/bin/sh
make
make fclean
make all
make clean
make
make re
make fclean
